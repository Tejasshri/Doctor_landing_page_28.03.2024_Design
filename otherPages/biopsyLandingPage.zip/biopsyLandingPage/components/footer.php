<footer>
    © CIPHER ONCOLOGY
</footer>
<a href="tel:18001202616" class="biopsy-call-us-footer-link call-us-footer">
    <img src="https://www.cioncancerclinics.com/cancerclinics/assets/images/call.png" alt="phone icon">Call us
</a>