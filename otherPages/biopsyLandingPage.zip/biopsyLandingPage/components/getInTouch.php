
<div class="get-in-touch">
    <img src="assets/Dr.naresh logo.webp" alt="dr.naresh-logo">
<div class="get-in-touch__inner__container">
    <h1 class="get-in-touch__h1">Get a Second Opinion</br> Make your right decision... Your Health Matters</h1>
<button><a href="#">Get in Touch</a></button>
</div>
</div>