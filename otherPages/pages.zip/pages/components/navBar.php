<nav>
    <img style="cursor: pointer;" src="../assets/cion-logo.webp" alt="cion-logo" onclick="toHome(event)">
    <a href="tel:18001202676" class="biopsy-contact-us-small"><img src="../assets/Phone-icon-sm.webp" alt="phone-icon"></a>
    <button class="biopsy-contact-us-medium"><a href="tel:18001202676">Contact Us</a></button>
</nav>
<script>
    function toHome(event) {
        window.location.href = "https://www.cioncancerclinics.com/"
    }
</script>